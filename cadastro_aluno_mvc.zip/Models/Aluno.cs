
using System;
using System.ComponentModel.DataAnnotations;

public class Aluno
{
    [Required]
    public string Nome { get; set; }

    [Required]
    [EmailAddress]
    public string Email { get; set; }

    [Required]
    public string RA { get; set; }

    [Required]
    public string Curso { get; set; }

    [Required]
    public DateTime DataNascimento { get; set; }
}
